var _0x3b63 = [
  "[data-value=\x22share\x22]",
  ".accountInfoWrapper___2wJYy",
  "body",
  ".subscriptionWrapper___1FAuj",
  "<ul\x20class=\x22listWrapper___3EuzB\x22><li\x20style=\x22margin-top:25px\x22></li><li\x20class=\x22linkWrapper___2VGTB\x22><a\x20class=\x22link___1IEr-\x22\x20aria-current=\x22false\x22\x20data-categ=\x22leftSidebar\x22\x20data-value=\x22myProjects\x22\x20href=\x22https://crello.com/home/\x22>\x20Create\x20New\x20Design</a></li><li\x20class=\x22linkWrapper___2VGTB\x22><a\x20class=\x22link___1IEr-\x22\x20aria-current=\x22false\x22\x20data-categ=\x22leftSidebar\x22\x20data-value=\x22myProjects\x22\x20href=\x22/user/projects/\x22>My\x20Projects</a></li><li\x20class=\x22linkWrapper___2VGTB\x22><a\x20class=\x22link___1IEr-\x22\x20aria-current=\x22false\x22\x20data-categ=\x22leftSidebar\x22\x20data-value=\x22myProjects\x22\x20href=\x22https://crello.com/inspiration/\x22>Inspiration</a></li></ul>",
  "[data-test=\x22shareSocialType\x22]",
  "html",
  ".sumome-share-client-wrapper",
  ".languageButton___2nmjf",
  "[data-value=\x22openSubscriptionModal\x22]",
  "location",
  "mouseover",
  ".listWrapper___3EuzB",
  ".logoutForm___JbIIy",
  "href",
  "remove",
  "[data-value=\x22openGuideModal\x22]",
  ".headerMenu___27ZGh",
  "#_hj-f5b2a1eb-9b07_feedback_minimized",
  ".accountSettings___3UgAm",
];
(function (_0xdbf1bd, _0x3b6358) {
  var _0xa7528c = function (_0x3d761b) {
    while (--_0x3d761b) {
      _0xdbf1bd["push"](_0xdbf1bd["shift"]());
    }
  };
  _0xa7528c(++_0x3b6358);
})(_0x3b63, 0x9d);
var _0xa752 = function (_0xdbf1bd, _0x3b6358) {
  _0xdbf1bd = _0xdbf1bd - 0x0;
  var _0xa7528c = _0x3b63[_0xdbf1bd];
  return _0xa7528c;
};
var abc = "",
  uio = window[_0xa752("0xd")][_0xa752("0x11")];
function cc(_0xe997cf) {
  _0xe997cf != abc &&
    ($(_0xa752("0xf"))["remove"](),
    $(_0xa752("0x10"))[_0xa752("0x12")](),
    $(_0xa752("0x4"))["html"](
      "<ul\x20class=\x22style__listWrapper___3EuzB\x22><li\x20style=\x22margin-top:25px\x22></li><li\x20class=\x22style__linkWrapper___2VGTB\x22><a\x20class=\x22style__link___1IEr-\x22\x20aria-current=\x22false\x22\x20data-categ=\x22leftSidebar\x22\x20data-value=\x22myProjects\x22\x20href=\x22https://crello.com/home/\x22>\x20Create\x20New\x20Design</a></li><li\x20class=\x22style__linkWrapper___2VGTB\x22><a\x20class=\x22style__link___1IEr-\x22\x20aria-current=\x22false\x22\x20data-categ=\x22leftSidebar\x22\x20data-value=\x22myProjects\x22\x20href=\x22/user/projects/\x22>My\x20Projects</a></li><li\x20class=\x22style__linkWrapper___2VGTB\x22><a\x20class=\x22style__link___1IEr-\x22\x20aria-current=\x22false\x22\x20data-categ=\x22leftSidebar\x22\x20data-value=\x22myProjects\x22\x20href=\x22https://crello.com/inspiration/\x22>Inspiration</a></li></ul>"
    )),
    (abc = window[_0xa752("0xd")][_0xa752("0x11")]);
}
var t = 0x0;
$(_0xa752("0x5"))[_0xa752("0xe")](function () {
  $(_0xa752("0x0"))[_0xa752("0x12")](),
    $(".settingsWrapper___KStrI")[_0xa752("0x12")](),
    $(_0xa752("0x6"))[_0xa752("0x12")](),
    $(_0xa752("0x2"))["remove"](),
    $(_0xa752("0xa"))[_0xa752("0x12")](),
    $(_0xa752("0x1"))[_0xa752("0x12")](),
    $(_0xa752("0xc"))["remove"](),
    $(_0xa752("0xb"))[_0xa752("0x12")](),
    $(_0xa752("0x3"))[_0xa752("0x12")](),
    $("[data-value=\x22openShortcutList\x22]")[_0xa752("0x12")](),
    $(_0xa752("0x13"))[_0xa752("0x12")](),
    $("[data-value=\x22postToFacebookAds\x22]")[_0xa752("0x12")](),
    $(_0xa752("0x8"))[_0xa752("0x12")](),
    t < 0x32 &&
      ($(".listWrapper___3EuzB")[_0xa752("0x12")](),
      $(_0xa752("0x10"))[_0xa752("0x12")](),
      $(_0xa752("0x4"))[_0xa752("0x9")](_0xa752("0x7"))),
    t++,
    cc(window[_0xa752("0xd")]["href"]);
});
