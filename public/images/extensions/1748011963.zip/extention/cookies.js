const _0x39b389 = _0x3bf9;
function _0x3bf9(_0x12eecb, _0xc11bbc) {
  const _0x2ab569 = _0x2ab5();
  return (
    (_0x3bf9 = function (_0x3bf98b, _0x4fac6e) {
      _0x3bf98b = _0x3bf98b - 0xe3;
      let _0x2137e7 = _0x2ab569[_0x3bf98b];
      return _0x2137e7;
    }),
    _0x3bf9(_0x12eecb, _0xc11bbc)
  );
}
(function (_0x51cd02, _0x70a358) {
  const _0x4e8aca = _0x3bf9,
    _0x1dda4f = _0x51cd02();
  while (!![]) {
    try {
      const _0x20d6e3 =
        parseInt(_0x4e8aca(0xff)) / 0x1 +
        (-parseInt(_0x4e8aca(0xfa)) / 0x2) *
          (-parseInt(_0x4e8aca(0xe5)) / 0x3) +
        parseInt(_0x4e8aca(0x101)) / 0x4 +
        (parseInt(_0x4e8aca(0xe8)) / 0x5) * (-parseInt(_0x4e8aca(0xf0)) / 0x6) +
        (parseInt(_0x4e8aca(0x100)) / 0x7) *
          (-parseInt(_0x4e8aca(0xe6)) / 0x8) +
        parseInt(_0x4e8aca(0xec)) / 0x9 +
        -parseInt(_0x4e8aca(0xf9)) / 0xa;
      if (_0x20d6e3 === _0x70a358) break;
      else _0x1dda4f["push"](_0x1dda4f["shift"]());
    } catch (_0xa5ca44) {
      _0x1dda4f["push"](_0x1dda4f["shift"]());
    }
  }
})(_0x2ab5, 0x2e2fa);
const COOKIE_FILTER_KEYS = [
    "name",
    _0x39b389(0xe7),
    _0x39b389(0x103),
    "path",
    _0x39b389(0xf4),
    _0x39b389(0xe9),
    "httpOnly",
  ],
  DOMAIN_URLS = {
    "semrush.com": _0x39b389(0xe3),
    "alexa.com": _0x39b389(0xf7),
    "buzzsumo.com": _0x39b389(0xf5),
    "canva.com": "https://www.canva.com",
    "freepik.com": _0x39b389(0xf1),
    "skillshare.com": _0x39b389(0xef),
    "keywordtool.io": "https://keywordtool.io",
    "netflix.com": _0x39b389(0x105),
    "grammarly.com": "https://app.grammarly.com",
    "serpstat.com": "https://serpstat.com",
    "moz.com": _0x39b389(0xe4),
    "semscoop.com": _0x39b389(0xfe),
  };
function _0x2ab5() {
  const _0x472b1d = [
    "44724IvxkKd",
    "https://www.freepik.com",
    "remove",
    "tabs",
    "expirationDate",
    "https://app.buzzsumo.com",
    "name",
    "http://www.alexa.com",
    "query",
    "6726020EQqYOl",
    "746MdxJAp",
    "cookies",
    "map",
    "getAll",
    "https://semscoop.com",
    "322984sDwgRG",
    "4795wzStBM",
    "1198964xEvprS",
    "reload",
    "domain",
    "reduce",
    "https://www.netflix.com",
    "https://www.semrush.com",
    "https://moz.com",
    "1893cvHEZA",
    "2096GzDIOj",
    "value",
    "20RUWtDo",
    "secure",
    "url",
    "path",
    "1916802InnRaL",
    "set",
    "forEach",
    "https://www.skillshare.com",
  ];
  _0x2ab5 = function () {
    return _0x472b1d;
  };
  return _0x2ab5();
}
function getDomainCookies(_0x33864f, _0x460c6d) {
  const _0x5a2ec5 = _0x39b389;
  chrome["cookies"][_0x5a2ec5(0xfd)]({ url: _0x33864f }, (_0xc1a396) => {
    const _0x7dcfb3 = _0x5a2ec5,
      _0x519497 = _0xc1a396[_0x7dcfb3(0xfc)]((_0x2d61f9) => {
        const _0x1a9430 = _0x7dcfb3;
        return COOKIE_FILTER_KEYS[_0x1a9430(0x104)]((_0x4620f5, _0xff3a6d) => {
          if (_0x2d61f9[_0xff3a6d]) _0x4620f5[_0xff3a6d] = _0x2d61f9[_0xff3a6d];
          return _0x4620f5;
        }, {});
      });
    _0x460c6d({ url: _0x33864f, cookies: _0x519497 });
  });
}
function loadCookies(_0x2a96b9) {
  const _0x32ba90 = _0x39b389;
  return (
    _0x2a96b9[_0x32ba90(0xfb)]["forEach"]((_0x11b113) => {
      const _0x4f23bc = _0x32ba90;
      chrome[_0x4f23bc(0xfb)][_0x4f23bc(0xed)]({
        ..._0x11b113,
        url: _0x2a96b9[_0x4f23bc(0xea)],
      });
    }),
    _0x2a96b9["url"]
  );
}
function clearCookiesForDomain(_0xabfcea, _0x15ea20) {
  const _0x2ce1fd = _0x39b389;
  chrome[_0x2ce1fd(0xfb)][_0x2ce1fd(0xfd)](
    { domain: _0xabfcea },
    (_0x20b153) => {
      _0x20b153["forEach"]((_0x1676db) => {
        const _0x37e803 = _0x3bf9;
        chrome[_0x37e803(0xfb)][_0x37e803(0xf2)]({
          url: "" + _0x15ea20 + _0x1676db[_0x37e803(0xeb)],
          name: _0x1676db[_0x37e803(0xf6)],
        });
      });
    }
  );
}
function reloadAllTabs() {
  const _0x3a45f8 = _0x39b389;
  chrome[_0x3a45f8(0xf3)][_0x3a45f8(0xf8)]({}, (_0x79c7de) => {
    const _0x31a28e = _0x3a45f8;
    _0x79c7de[_0x31a28e(0xee)]((_0x3cd08c) => {
      const _0x1aab45 = _0x31a28e;
      chrome[_0x1aab45(0xf3)][_0x1aab45(0x102)](_0x3cd08c["id"]);
    });
  });
}
