$("#afterExtaV3").removeClass("d-none");
$("#berofrExtensionaV3").addClass("d-none");
var _0x1af971 = _0x25d2;
function _0x1488() {
  var _0xcc6062 = [
    "i\x20am\x20clicked",
    "text",
    "2660CCRYjL",
    "121BUEFbr",
    "sendMessage",
    "542uBdWDt",
    ".clkbtn1",
    "27608rrhgnq",
    "8253830XDScFd",
    "1195RIYFOv",
    "237657UyAsRh",
    "422844kNlSOe",
    "18yDeUIA",
    "#u1",
    "off",
    "6172SnPNwx",
    "8874DxhQZJ",
    "runtime",
    "click",
    "1051YpbNHO",
  ];
  _0x1488 = function () {
    return _0xcc6062;
  };
  return _0x1488();
}
function _0x25d2(_0x20e53f, _0x368134) {
  var _0x14888c = _0x1488();
  return (
    (_0x25d2 = function (_0x25d235, _0xb07554) {
      _0x25d235 = _0x25d235 - 0x64;
      var _0x23918b = _0x14888c[_0x25d235];
      return _0x23918b;
    }),
    _0x25d2(_0x20e53f, _0x368134)
  );
}
(function (_0x4095fd, _0x1f3f8b) {
  var _0x1fdc66 = _0x25d2,
    _0x52d7b8 = _0x4095fd();
  while (!![]) {
    try {
      var _0x4e5fa4 =
        (parseInt(_0x1fdc66(0x6f)) / 0x1) * (parseInt(_0x1fdc66(0x75)) / 0x2) +
        -parseInt(_0x1fdc66(0x66)) / 0x3 +
        (parseInt(_0x1fdc66(0x6b)) / 0x4) * (-parseInt(_0x1fdc66(0x65)) / 0x5) +
        (-parseInt(_0x1fdc66(0x6c)) / 0x6) * (parseInt(_0x1fdc66(0x72)) / 0x7) +
        (parseInt(_0x1fdc66(0x77)) / 0x8) * (-parseInt(_0x1fdc66(0x68)) / 0x9) +
        parseInt(_0x1fdc66(0x64)) / 0xa +
        (parseInt(_0x1fdc66(0x73)) / 0xb) * (parseInt(_0x1fdc66(0x67)) / 0xc);
      if (_0x4e5fa4 === _0x1f3f8b) break;
      else _0x52d7b8["push"](_0x52d7b8["shift"]());
    } catch (_0x3d106d) {
      _0x52d7b8["push"](_0x52d7b8["shift"]());
    }
  }
})(_0x1488, 0x7567d),
  $(_0x1af971(0x76))
    [_0x1af971(0x6a)](_0x1af971(0x6e))
    ["on"](_0x1af971(0x6e), function () {
      var _0x43ad6e = _0x1af971,
        _0x3dcdbf = $("#p1")[_0x43ad6e(0x71)](),
        _0x5010a4 = $(_0x43ad6e(0x69))[_0x43ad6e(0x71)](),
        _0x423b9d = $("#user_profileName")[_0x43ad6e(0x71)]();
      chrome[_0x43ad6e(0x6d)][_0x43ad6e(0x74)]({
        action: "buttonClicked",
        datas: _0x3dcdbf,
        usagt: _0x5010a4,
        user_profileName: _0x423b9d,
      }),
        console["log"](_0x43ad6e(0x70));
    });
