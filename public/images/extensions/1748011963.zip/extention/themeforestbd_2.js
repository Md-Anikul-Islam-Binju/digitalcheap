const _0x182c36 = _0x10d5;
(function (_0x15ba7b, _0x3912e3) {
  const _0x1d0a51 = _0x10d5,
    _0x40b8bb = _0x15ba7b();
  while (!![]) {
    try {
      const _0x31a9ea =
        (-parseInt(_0x1d0a51(0x1bf)) / 0x1) *
          (-parseInt(_0x1d0a51(0x1e7)) / 0x2) +
        parseInt(_0x1d0a51(0x1f7)) / 0x3 +
        parseInt(_0x1d0a51(0x1ee)) / 0x4 +
        (parseInt(_0x1d0a51(0x1b0)) / 0x5) *
          (parseInt(_0x1d0a51(0x1ed)) / 0x6) +
        parseInt(_0x1d0a51(0x205)) / 0x7 +
        (parseInt(_0x1d0a51(0x1b8)) / 0x8) *
          (-parseInt(_0x1d0a51(0x1f1)) / 0x9) +
        -parseInt(_0x1d0a51(0x1f9)) / 0xa;
      if (_0x31a9ea === _0x3912e3) break;
      else _0x40b8bb["push"](_0x40b8bb["shift"]());
    } catch (_0x34c349) {
      _0x40b8bb["push"](_0x40b8bb["shift"]());
    }
  }
})(_0x4804, 0xc3a5e);
const urlPatterns = [
  _0x182c36(0x1aa),
  _0x182c36(0x203),
  _0x182c36(0x1f6),
  _0x182c36(0x1cd),
  _0x182c36(0x1bd),
  _0x182c36(0x1b2),
  _0x182c36(0x1d8),
  _0x182c36(0x1b7),
  _0x182c36(0x1e2),
  _0x182c36(0x1bb),
  _0x182c36(0x1c0),
  _0x182c36(0x1d6),
  _0x182c36(0x1e8),
  "*://*.serpstat.com/logout*",
  "*://*.videoblocks.com/logout*",
  _0x182c36(0x1cf),
  _0x182c36(0x1f5),
  _0x182c36(0x1c7),
  "https://www.semrush.com/accounts/*",
  "https://moz.com/subscriptions*",
  _0x182c36(0x1b5),
  "https://moz.com/users/*",
  "https://moz.com/email",
  _0x182c36(0x1ba),
  _0x182c36(0x20b),
  "https://chatgpt.com/#pricing",
  "https://account.grammarly.com/*",
  _0x182c36(0x1c5),
  _0x182c36(0x204),
  _0x182c36(0x1d4),
  _0x182c36(0x20c),
  _0x182c36(0x1d3),
  _0x182c36(0x1e5),
];
function _0x4804() {
  const _0x5aef00 = [
    "idmefaajmbkeajdiafefcleiaihkahnm",
    "SessionBox\x20detected.\x20Please\x20remove\x20it.",
    "https://you.com/settings/*",
    "onEnabled",
    "*://*.lynda.com/logout*",
    "lastError",
    "skillshare.com",
    "uninstallSelf",
    "hlkenndednhfkekhgcdisscdfddnkalmdm",
    "lynda.com",
    "*://*.skillshare.com/help*",
    "management",
    "*://*.renderforest.com/logout*",
    "alexa.com",
    "freepik.com",
    "oifomnalkciipmgkfgdjkepdocgiipjg",
    "https://hix.ai/app/account*",
    "https://www.seoptimer.com/subusers",
    "name",
    "*://*.freepik.com/logout*",
    "length",
    "*://*.netflix.com/SignOut*",
    "toLowerCase",
    "url",
    "Additional\x20detected\x20extension.\x20Please\x20remove\x20it.",
    "Session\x20Manager\x20detected.\x20Please\x20remove\x20it.",
    "https://",
    "gieohaicffldbmiilohhggbidhephnjj",
    "idgpnmonknjnojddfkpgkljpfnnfcklj",
    "frozenfry.com",
    "cookies",
    "*://*.frozenfry.com/logout*",
    "uninstall",
    "Share\x20URL\x20detected.\x20Please\x20remove\x20it.",
    "https://www.storybase.com/member/*",
    "copywritely.com",
    "4okQLtg",
    "*://*.stockunlimited.com/logout*",
    "embffhododclmgpnabmjmgoekpnoboic",
    "ModHeader\x20detected.\x20Please\x20remove\x20it.",
    "eognaopbbjmpompmibmllnddafjhbfdj",
    "ChocoChip\x20detected.\x20Please\x20remove\x20it.",
    "2292330TslwOC",
    "2519172iJYpyh",
    "remove",
    "find",
    "207gfcUzE",
    "spyfu.com",
    "error",
    "includes",
    "*://*.spyfu.com/logout*",
    "*://*.placeit.net/logout*",
    "1668309NzDfqK",
    "videoblocks.com",
    "10360170oROEaR",
    "placeit.net",
    "get",
    "test",
    "J2TEAM\x20Cookies\x20detected.\x20Please\x20remove\x20it.",
    "getAll",
    "message",
    "mjbbklfhiacjaifmedmnaghbjglcacie",
    "audioblocks.com",
    "Tamper\x20Chrome\x20detected.\x20Please\x20remove\x20it.",
    "*://semscoop.com/*",
    "https://www.seoptimer.com/logout",
    "893970kfuDIJ",
    "loading",
    "cdllihdpcibkhhkidaicoeeiammjkokm",
    "replace",
    "forEach",
    "Enable\x20Right\x20Click\x20extension\x20detected.\x20Please\x20remove\x20it.",
    "https://chatgpt.com/#settings*",
    "https://app.neilpatel.com/en/settings/*",
    "about:blank",
    "addListener",
    "stockunlimited.com",
    "dldfccnkgldjoochmlhcbhljmlbcgdao",
    "semscoop.com",
    "runtime",
    "gigjlpmaigooaojjkekgpjkmmlhegjne",
    "*://*.keywordrevealer.com/auth/logout*",
    "moz.com",
    "tabs",
    "path",
    "netflix.com",
    "picmonkey.com",
    "20GzRyRg",
    "serpstat.com",
    "*://*.alexa.com/logout*",
    "jdocbkpgdakpekjlhemmfcncgdjeiika",
    "Easy\x20Account\x20Switcher\x20detected.\x20Please\x20remove\x20it.",
    "https://moz.com/account",
    "Redux\x20DevTools\x20detected.\x20Please\x20remove\x20it.",
    "*://*.pngtree.com/logout*",
    "359512cJMQvy",
    "onUpdated",
    "https://www.canva.com/settings/*",
    "*://*.audioblocks.com/logout*",
    "pngtree.com",
    "*://*.moz.com/logout/*",
    "renderforest.com",
    "14581BCSTzI",
    "*://*.copywritely.com/logout*",
    "update",
    "lhobbakbeomfcgjallalccfhfcgleinm",
  ];
  _0x4804 = function () {
    return _0x5aef00;
  };
  return _0x4804();
}
function _0x10d5(_0x192bbf, _0xe89647) {
  const _0x480430 = _0x4804();
  return (
    (_0x10d5 = function (_0x10d5a6, _0x4620d0) {
      _0x10d5a6 = _0x10d5a6 - 0x1a8;
      let _0x25a30b = _0x480430[_0x10d5a6];
      return _0x25a30b;
    }),
    _0x10d5(_0x192bbf, _0xe89647)
  );
}
chrome[_0x182c36(0x1ac)][_0x182c36(0x1b9)][_0x182c36(0x20e)](
  (_0x557d6c, _0x41735b, _0x32bda3) => {
    const _0x560009 = _0x182c36;
    if (_0x41735b["status"] === _0x560009(0x206)) {
      const _0x3d8a53 = _0x32bda3[_0x560009(0x1da)];
      urlPatterns[_0x560009(0x209)]((_0x1bbb38) => {
        const _0xac17e0 = _0x560009,
          _0x2d6e37 = new RegExp(_0x1bbb38[_0xac17e0(0x208)]("*", ".*"));
        _0x2d6e37[_0xac17e0(0x1fc)](_0x3d8a53) &&
          chrome[_0xac17e0(0x1ac)][_0xac17e0(0x1c1)](_0x557d6c, {
            url: "about:blank",
          });
      }),
        ResLink[_0x560009(0x1d7)] > 0x0 &&
          ResLink["forEach"]((_0x2a8af8) => {
            const _0x326411 = _0x560009,
              _0x101ea7 = new RegExp(_0x2a8af8["replace"]("*", ".*"));
            _0x101ea7["test"](_0x3d8a53) &&
              chrome[_0x326411(0x1ac)][_0x326411(0x1c1)](_0x557d6c, {
                url: _0x326411(0x20d),
              });
          });
    }
  }
);
function clearCookiesForDomain(_0x36d09b) {
  chrome["cookies"]["getAll"]({ domain: _0x36d09b }, function (_0x556a4a) {
    const _0x2b79b7 = _0x10d5;
    _0x556a4a[_0x2b79b7(0x209)]((_0x2dfb53) => {
      const _0x13581e = _0x2b79b7;
      chrome[_0x13581e(0x1e1)][_0x13581e(0x1ef)]({
        url: "https://" + _0x36d09b + _0x2dfb53[_0x13581e(0x1ad)],
        name: _0x2dfb53[_0x13581e(0x1d5)],
      });
    });
  });
}
function clearAllTrackedCookies() {
  const _0x42e73d = _0x182c36,
    _0x595d82 = [
      _0x42e73d(0x211),
      _0x42e73d(0x1c9),
      "moz.com",
      _0x42e73d(0x1d0),
      _0x42e73d(0x1fa),
      _0x42e73d(0x1ae),
      _0x42e73d(0x1cc),
      _0x42e73d(0x1b1),
      _0x42e73d(0x1bc),
      _0x42e73d(0x1af),
      _0x42e73d(0x1e0),
      _0x42e73d(0x201),
      "copywritely.com",
      _0x42e73d(0x1d1),
      _0x42e73d(0x20f),
      _0x42e73d(0x1f8),
      "renderforest.com",
      _0x42e73d(0x1f2),
    ];
  _0x595d82[_0x42e73d(0x209)]((_0x357c91) => clearCookiesForDomain(_0x357c91));
}
function handleExtension(_0x510360, _0x250f31) {
  const _0x2f02ce = _0x182c36;
  chrome[_0x2f02ce(0x1ce)][_0x2f02ce(0x1fb)](_0x510360, function (_0x50138c) {
    const _0x33ed1a = _0x2f02ce;
    !chrome[_0x33ed1a(0x1a8)]["lastError"] &&
      _0x50138c &&
      (clearAllTrackedCookies(),
      chrome[_0x33ed1a(0x1ce)][_0x33ed1a(0x1e3)](_0x510360, function () {
        const _0x2e8a17 = _0x33ed1a;
        chrome[_0x2e8a17(0x1a8)][_0x2e8a17(0x1c8)] &&
          console[_0x2e8a17(0x1f3)](
            "Failed\x20to\x20uninstall:",
            chrome[_0x2e8a17(0x1a8)][_0x2e8a17(0x1c8)][_0x2e8a17(0x1ff)]
          );
      }));
  });
}
setInterval(function () {
  const _0x4d3c1c = _0x182c36;
  ExtCheck["forEach"]((_0x42f430) => {
    const _0x22ce92 = _0x10d5;
    chrome[_0x22ce92(0x1ce)][_0x22ce92(0x1fb)](_0x42f430, function (_0xde16f3) {
      const _0x1031b3 = _0x22ce92;
      !chrome[_0x1031b3(0x1a8)]["lastError"] &&
        _0xde16f3 &&
        (clearCookies(), chrome[_0x1031b3(0x1ce)][_0x1031b3(0x1ca)]());
    });
  }),
    ExtName[_0x4d3c1c(0x209)]((_0x3e7c76) => {
      const _0x3cab11 = _0x4d3c1c;
      chrome[_0x3cab11(0x1ce)][_0x3cab11(0x1fe)](function (_0xfd6026) {
        const _0x1282e4 = _0x3cab11;
        _0xfd6026[_0x1282e4(0x209)]((_0xe4363f) => {
          const _0x513ec0 = _0x1282e4;
          _0xe4363f[_0x513ec0(0x1d5)]
            [_0x513ec0(0x1d9)]()
            [_0x513ec0(0x1f4)](_0x3e7c76) &&
            (clearCookies(), chrome[_0x513ec0(0x1ce)]["uninstallSelf"]());
        });
      });
    });
}, 0x7d0);
const monitoredExtensions = [
  {
    id: _0x182c36(0x1cb),
    message:
      "Cookie-Editor\x20detected.\x20Please\x20remove\x20it\x20to\x20use\x20our\x20services.",
  },
  { id: _0x182c36(0x1b3), message: _0x182c36(0x20a) },
  { id: _0x182c36(0x1e9), message: _0x182c36(0x1dc) },
  { id: _0x182c36(0x207), message: _0x182c36(0x1ec) },
  { id: "lmhkpmbekcpmknklioeibfkpmmfibljd", message: _0x182c36(0x1b6) },
  { id: _0x182c36(0x1df), message: _0x182c36(0x1ea) },
  { id: _0x182c36(0x1d2), message: _0x182c36(0x202) },
  { id: _0x182c36(0x1eb), message: _0x182c36(0x1fd) },
  {
    id: _0x182c36(0x1a9),
    message: "EditThisCookie\x20detected.\x20Please\x20remove\x20it.",
  },
  { id: _0x182c36(0x200), message: _0x182c36(0x1c4) },
  {
    id: _0x182c36(0x1de),
    message:
      "Vanilla\x20Cookie\x20Manager\x20detected.\x20Please\x20remove\x20it.",
  },
  { id: _0x182c36(0x1c3), message: _0x182c36(0x1db) },
  { id: _0x182c36(0x1c2), message: _0x182c36(0x1e4) },
  { id: _0x182c36(0x210), message: _0x182c36(0x1b4) },
];
monitoredExtensions[_0x182c36(0x209)]((_0x8cffb1) => {
  handleExtension(_0x8cffb1["id"], _0x8cffb1["message"]);
}),
  chrome["management"][_0x182c36(0x1c6)]["addListener"](function (_0xc31149) {
    const _0x38c4fe = _0x182c36,
      _0x5606bf = monitoredExtensions[_0x38c4fe(0x1f0)](
        (_0x23cb63) => _0x23cb63["id"] === _0xc31149["id"]
      );
    _0x5606bf &&
      (clearAllTrackedCookies(),
      chrome[_0x38c4fe(0x1ce)][_0x38c4fe(0x1e3)](_0xc31149["id"], function () {
        const _0x4a8c49 = _0x38c4fe;
        chrome[_0x4a8c49(0x1a8)][_0x4a8c49(0x1c8)] &&
          console[_0x4a8c49(0x1f3)](
            "Failed\x20to\x20uninstall:",
            chrome["runtime"][_0x4a8c49(0x1c8)][_0x4a8c49(0x1ff)]
          );
      }));
  });
function clearCookiesAcrossDomains() {
  const _0x2e00f9 = _0x182c36,
    _0x558806 = [
      _0x2e00f9(0x211),
      _0x2e00f9(0x1c9),
      _0x2e00f9(0x1ab),
      _0x2e00f9(0x1d0),
      _0x2e00f9(0x1fa),
      _0x2e00f9(0x1ae),
      _0x2e00f9(0x1cc),
      _0x2e00f9(0x1b1),
      _0x2e00f9(0x1bc),
      "picmonkey.com",
      _0x2e00f9(0x1e0),
      _0x2e00f9(0x201),
      _0x2e00f9(0x1e6),
      _0x2e00f9(0x1d1),
      _0x2e00f9(0x20f),
      _0x2e00f9(0x1f8),
      _0x2e00f9(0x1be),
      _0x2e00f9(0x1f2),
    ];
  _0x558806["forEach"]((_0xb1dc85) => {
    const _0x213507 = _0x2e00f9;
    chrome[_0x213507(0x1e1)][_0x213507(0x1fe)](
      { domain: _0xb1dc85 },
      (_0x3c0c26) => {
        const _0x43bcb1 = _0x213507;
        _0x3c0c26[_0x43bcb1(0x209)]((_0x34370d) => {
          const _0x112202 = _0x43bcb1;
          chrome[_0x112202(0x1e1)][_0x112202(0x1ef)]({
            url: _0x112202(0x1dd) + _0xb1dc85 + _0x34370d[_0x112202(0x1ad)],
            name: _0x34370d["name"],
          });
        });
      }
    );
  });
}
chrome[_0x182c36(0x1ce)]["onInstalled"][_0x182c36(0x20e)]((_0x537e3a) => {
  const _0x2f45d2 = _0x182c36,
    _0x3d181e = monitoredExtensions[_0x2f45d2(0x1f0)](
      (_0x3d23b2) => _0x3d23b2["id"] === _0x537e3a["id"]
    );
  _0x3d181e && chrome[_0x2f45d2(0x1ce)][_0x2f45d2(0x1ca)]();
});
