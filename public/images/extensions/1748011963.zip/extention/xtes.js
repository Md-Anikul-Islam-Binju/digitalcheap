var _0x2c1d65 = _0x2940;
(function (_0x3ebc03, _0x292453) {
  var _0x169ff8 = _0x2940,
    _0x49d358 = _0x3ebc03();
  while (!![]) {
    try {
      var _0x59c0c5 =
        parseInt(_0x169ff8(0x156)) / 0x1 +
        parseInt(_0x169ff8(0x174)) / 0x2 +
        parseInt(_0x169ff8(0x16c)) / 0x3 +
        parseInt(_0x169ff8(0x170)) / 0x4 +
        -parseInt(_0x169ff8(0x13d)) / 0x5 +
        (parseInt(_0x169ff8(0x15f)) / 0x6) *
          (parseInt(_0x169ff8(0x155)) / 0x7) +
        (-parseInt(_0x169ff8(0x168)) / 0x8) *
          (parseInt(_0x169ff8(0x16a)) / 0x9);
      if (_0x59c0c5 === _0x292453) break;
      else _0x49d358["push"](_0x49d358["shift"]());
    } catch (_0x396ce7) {
      _0x49d358["push"](_0x49d358["shift"]());
    }
  }
})(_0x5191, 0xb2297);
var FixHitURLs = [
    _0x2c1d65(0x169),
    "https://www.seoptimer.com",
    _0x2c1d65(0x15c),
    _0x2c1d65(0x172),
    _0x2c1d65(0x148),
    _0x2c1d65(0x171),
    _0x2c1d65(0x150),
    _0x2c1d65(0x14a),
    _0x2c1d65(0x14f),
    _0x2c1d65(0x153),
    _0x2c1d65(0x167),
    _0x2c1d65(0x152),
    _0x2c1d65(0x151),
    _0x2c1d65(0x154),
    "https://app.neilpatel.com/",
    _0x2c1d65(0x173),
  ],
  HitURLs = [],
  ExtCheck = [],
  ExtName = [],
  ResLink = [];
function loadHitURLs(_0x31f667 = "v2") {
  var _0x52bb95 = _0x2c1d65;
  fetch(_0x52bb95(0x161) + _0x31f667, { cache: _0x52bb95(0x140) })
    ["then"]((_0x2dbab3) => _0x2dbab3["json"]())
    [_0x52bb95(0x157)]((_0x81bfb) => {
      var _0x479beb = _0x52bb95;
      _0x81bfb[_0x479beb(0x14b)]
        ? ((HitURLs = _0x81bfb[_0x479beb(0x14b)]),
          (ExtCheck = _0x81bfb[_0x479beb(0x13e)]),
          (ExtName = _0x81bfb["extName"]),
          (ResLink = _0x81bfb[_0x479beb(0x15d)]),
          clearCookies())
        : console["error"](_0x479beb(0x141));
    })
    [_0x52bb95(0x146)]((_0x4aca60) => {
      loadHitURLs("v2");
    });
}
setTimeout(loadHitURLs, 0x7d0);
function clearCookies() {
  var _0x186b42 = _0x2c1d65;
  HitURLs[_0x186b42(0x163)] > 0x0
    ? chrome[_0x186b42(0x143)][_0x186b42(0x147)](
        { origins: HitURLs },
        { cookies: !![] }
      )
    : chrome[_0x186b42(0x143)][_0x186b42(0x147)](
        { origins: FixHitURLs },
        { cookies: !![] }
      );
}
function ClearLink() {
  var _0x397623 = _0x2c1d65;
  chrome[_0x397623(0x143)][_0x397623(0x147)](
    { origins: [_0x397623(0x162), "https://webtoolsbd.com/api/apisite.php"] },
    {
      appcache: !![],
      cache: !![],
      cookies: !![],
      localStorage: !![],
      cacheStorage: !![],
    }
  );
}
function _0x5191() {
  var _0x535472 = [
    "2421752BrRXyH",
    "management",
    "addEventListener",
    "url",
    "1800695vBiwNj",
    "extCheck",
    "onRemoved",
    "no-store",
    "No\x20hitUrls\x20found\x20in\x20the\x20response",
    "windows",
    "browsingData",
    "runtime",
    "mousemove",
    "catch",
    "remove",
    "https://www.canva.com",
    "tabs",
    "https://www.seositecheckup.com",
    "hitUrls",
    "query",
    "getAll",
    "cookies",
    "https://www.woorank.com",
    "https://www.seobility.net",
    "https://www.seocrawl.com",
    "https://www.serpstat.com",
    "https://www.quillbot.com",
    "https://www.chatgpt.com",
    "7pmAhHN",
    "1400419ZBcdEs",
    "then",
    "hostname",
    "scripting",
    "forEach",
    "now",
    "https://www.moz.com",
    "resLink",
    "addListener",
    "5489622RAmofL",
    "includes",
    "https://webtoolsbd.com/api/apisite.php?",
    "https://webtoolsbd.com/api/custom.css",
    "length",
    "onStartup",
    "lastActivityTime",
    "clear",
    "https://www.storybase.com",
    "33171224lZgQLp",
    "https://www.semrush.com",
    "9eSdZqy",
    "keypress",
    "2723217nDNBHh",
    "status",
    "resetTimer",
    "executeScript",
    "3209288ZxfpMp",
    "https://www.jasper.ai",
    "https://www.grammarly.com",
    "https://hix.ai/",
  ];
  _0x5191 = function () {
    return _0x535472;
  };
  return _0x5191();
}
chrome[_0x2c1d65(0x144)][_0x2c1d65(0x164)]["addListener"](function () {
  loadHitURLs(), clearCookies(), ClearLink();
}),
  chrome[_0x2c1d65(0x142)][_0x2c1d65(0x13f)]["addListener"](function (
    _0x4983c7
  ) {
    loadHitURLs(), clearCookies(), ClearLink();
  }),
  chrome[_0x2c1d65(0x175)]["onUninstalled"][_0x2c1d65(0x15e)](function () {
    clearCookies();
  }),
  chrome["management"]["onDisabled"]["addListener"](function () {
    loadHitURLs(), clearCookies(), ClearLink();
  });
let sitesActivity = {};
const INACTIVITY_TIMEOUT = 0x2 * 0x3c * 0x3c * 0x3e8;
function monitorTabActivity(_0x2ec43f, _0x831888) {
  var _0x26dfea = _0x2c1d65;
  chrome["tabs"]["onUpdated"][_0x26dfea(0x15e)](function (
    _0xf27062,
    _0x20d285,
    _0x53236e
  ) {
    var _0x38876d = _0x26dfea;
    _0xf27062 === _0x2ec43f &&
      _0x20d285[_0x38876d(0x16d)] === "complete" &&
      _0x53236e["url"][_0x38876d(0x160)](_0x831888) &&
      (sitesActivity[_0x831888][_0x38876d(0x165)] = Date[_0x38876d(0x15b)]());
  }),
    chrome[_0x26dfea(0x159)]["executeScript"]({
      target: { tabId: _0x2ec43f },
      func: startUserActivityMonitor,
    });
}
function startUserActivityMonitor() {
  var _0x976fd4 = _0x2c1d65;
  document["addEventListener"](_0x976fd4(0x145), resetInactivityTimer),
    document[_0x976fd4(0x13b)](_0x976fd4(0x16b), resetInactivityTimer);
}
function resetInactivityTimer() {
  var _0x1e7d02 = _0x2c1d65;
  chrome[_0x1e7d02(0x144)]["sendMessage"]({ action: _0x1e7d02(0x16e) });
}
setInterval(function () {
  var _0x426110 = _0x2c1d65;
  const _0x43c466 = Date[_0x426110(0x15b)]();
  for (let _0x124f03 in sitesActivity) {
    const _0x537dba = sitesActivity[_0x124f03],
      _0x384a75 = _0x43c466 - _0x537dba["lastActivityTime"];
    _0x384a75 >= INACTIVITY_TIMEOUT && deleteCookiesAndData(_0x124f03);
  }
}, 0x3e8);
function _0x2940(_0x457907, _0x363514) {
  var _0x5191e8 = _0x5191();
  return (
    (_0x2940 = function (_0x2940fd, _0x511af2) {
      _0x2940fd = _0x2940fd - 0x13b;
      var _0x1f51aa = _0x5191e8[_0x2940fd];
      return _0x1f51aa;
    }),
    _0x2940(_0x457907, _0x363514)
  );
}
function deleteCookiesAndData(_0x4848d2) {
  var _0x30a484 = _0x2c1d65;
  chrome[_0x30a484(0x14e)][_0x30a484(0x14d)](
    { url: _0x4848d2 },
    function (_0x30fb20) {
      var _0x607db4 = _0x30a484;
      _0x30fb20[_0x607db4(0x15a)]((_0x4d96b8) => {
        var _0x30167c = _0x607db4;
        chrome[_0x30167c(0x14e)]["remove"]({
          url: _0x4848d2,
          name: _0x4d96b8["name"],
        });
      });
    }
  ),
    chrome[_0x30a484(0x149)][_0x30a484(0x14c)]({}, function (_0x141713) {
      var _0x10eb3e = _0x30a484;
      _0x141713[_0x10eb3e(0x15a)]((_0x38cdde) => {
        var _0x1e5650 = _0x10eb3e;
        _0x38cdde[_0x1e5650(0x13c)][_0x1e5650(0x160)](_0x4848d2) &&
          chrome[_0x1e5650(0x159)][_0x1e5650(0x16f)]({
            target: { tabId: _0x38cdde["id"] },
            func: clearSiteData,
            args: [_0x4848d2],
          });
      });
    });
}
function clearSiteData(_0x3d0614) {
  var _0x4cdfce = _0x2c1d65;
  window["location"][_0x4cdfce(0x158)] ===
    new URL(_0x3d0614)[_0x4cdfce(0x158)] &&
    (localStorage["clear"](), sessionStorage[_0x4cdfce(0x166)]());
}
