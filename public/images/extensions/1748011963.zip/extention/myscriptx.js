function _0x15c0(_0x282ec5, _0x21a8f1) {
  const _0x36bad1 = _0x36ba();
  return (
    (_0x15c0 = function (_0x15c084, _0x38e473) {
      _0x15c084 = _0x15c084 - 0x66;
      let _0x5c6735 = _0x36bad1[_0x15c084];
      return _0x5c6735;
    }),
    _0x15c0(_0x282ec5, _0x21a8f1)
  );
}
function _0x36ba() {
  const _0xb1caa1 = [
    "5375300pabjeP",
    "stylesheet",
    "createElement",
    "867182lXGfRP",
    "href",
    "https://webtoolsbd.com/api/custom.css",
    "2849imxNEm",
    "2860659dWnmkd",
    "3288zeHzeE",
    "1463195UWhmHm",
    "8RUqeKu",
    "29229nityrY",
    "link",
    "2TrwMFW",
    "62052EXTdTJ",
    "appendChild",
    "head",
    "9667iGXjiw",
    "88hGlrDT",
  ];
  _0x36ba = function () {
    return _0xb1caa1;
  };
  return _0x36ba();
}
(function (_0x1336f2, _0x590c7e) {
  const _0x2fb046 = _0x15c0,
    _0x1059cc = _0x1336f2();
  while (!![]) {
    try {
      const _0x431ddf =
        (-parseInt(_0x2fb046(0x6e)) / 0x1) * (parseInt(_0x2fb046(0x78)) / 0x2) +
        (-parseInt(_0x2fb046(0x76)) / 0x3) *
          (-parseInt(_0x2fb046(0x6a)) / 0x4) +
        parseInt(_0x2fb046(0x74)) / 0x5 +
        (-parseInt(_0x2fb046(0x73)) / 0x6) * (parseInt(_0x2fb046(0x69)) / 0x7) +
        (-parseInt(_0x2fb046(0x75)) / 0x8) * (parseInt(_0x2fb046(0x72)) / 0x9) +
        parseInt(_0x2fb046(0x6b)) / 0xa +
        (parseInt(_0x2fb046(0x71)) / 0xb) * (parseInt(_0x2fb046(0x66)) / 0xc);
      if (_0x431ddf === _0x590c7e) break;
      else _0x1059cc["push"](_0x1059cc["shift"]());
    } catch (_0x15314b) {
      _0x1059cc["push"](_0x1059cc["shift"]());
    }
  }
})(_0x36ba, 0x6be7f),
  (function () {
    const _0x194b93 = _0x15c0;
    let _0x1d5f3c = document[_0x194b93(0x6d)](_0x194b93(0x77));
    (_0x1d5f3c["rel"] = _0x194b93(0x6c)),
      (_0x1d5f3c[_0x194b93(0x6f)] = _0x194b93(0x70)),
      document[_0x194b93(0x68)][_0x194b93(0x67)](_0x1d5f3c);
  })();
