var _0x43aa = [
  ".limit-message",
  ".mgn-nav-extra",
  ".subnav\x20.container\x20.subnav-items",
  "none",
  "<a\x20href=\x27https://moz.com/researchtools/ose/\x27\x20title=\x27Open\x20Site\x20Explorer\x27\x20style=\x27position:\x20relative;padding:\x203px\x2010px\x200;color:\x20#000000;height:\x2056px;line-height:\x2056px;overflow:\x20hidden;font-size:\x2016px;\x27>Link\x20Explorer</a><a\x20href=\x27https://moz.com/researchtools/fwe/\x27\x20title=\x27Fresh\x20Web\x20Explorer\x27\x20style=\x27position:\x20relative;padding:\x203px\x2010px\x200;color:\x20#000000;height:\x2056px;line-height:\x2056px;overflow:\x20hidden;font-size:\x2016px;\x27>Fresh\x20Web\x20Explorer</a><a\x20href=\x27https://moz.com/explorer\x27\x20title=\x27Keyword\x20Difficulty\x27\x20style=\x27position:\x20relative;padding:\x203px\x2010px\x200;color:\x20#000000;height:\x2056px;line-height:\x2056px;overflow:\x20hidden;font-size:\x2016px;\x27>Keyword\x20Explorer</a><a\x20href=\x27https://moz.com/researchtools/on-page-grader\x27\x20title=\x27On-Page\x20Grader\x27\x20style=\x27position:\x20relative;padding:\x203px\x2010px\x200;color:\x20#000000;height:\x2056px;line-height:\x2056px;overflow:\x20hidden;font-size:\x2016px;\x27>On-Page\x20Grader</a><a\x20href=\x27https://moz.com/researchtools/rank-tracker\x27\x20title=\x27Rank\x20Tracker\x27\x20style=\x27position:\x20relative;padding:\x203px\x2010px\x200;color:\x20#000000;height:\x2056px;line-height:\x2056px;overflow:\x20hidden;font-size:\x2016px;\x27>Rank\x20Tracker</a>",
  ".book-demo-banner-vertical-trial",
  ".free-trial.free-trial-vertical",
  ".subnav.container\x20.subnav-primary-items\x20.subnav-dropdown",
  "footer",
  ".book-demo-banner-horizontal-trial",
  ".mgn-nav-meta",
  "border",
  "html",
  "css",
  "mouseover",
  "remove",
  ".free-trial.box",
  ".links-quota",
];
(function (_0x1fef71, _0x43aac4) {
  var _0x2a402b = function (_0x26cda1) {
    while (--_0x26cda1) {
      _0x1fef71["push"](_0x1fef71["shift"]());
    }
  };
  _0x2a402b(++_0x43aac4);
})(_0x43aa, 0xea);
var _0x2a40 = function (_0x1fef71, _0x43aac4) {
  _0x1fef71 = _0x1fef71 - 0x0;
  var _0x2a402b = _0x43aa[_0x1fef71];
  return _0x2a402b;
};
$(".mgn-profile.mgn-selectable")[_0x2a40("0xc")](""),
  $(_0x2a40("0x1"))[_0x2a40("0xc")](_0x2a40("0x4")),
  $(_0x2a40("0xa"))["html"](""),
  $("body")[_0x2a40("0xe")](function () {
    $(".book-demo-banner-vertical-trial")[_0x2a40("0xf")](),
      $(_0x2a40("0x9"))[_0x2a40("0xf")](),
      $(_0x2a40("0x10"))[_0x2a40("0xf")](),
      $(_0x2a40("0x6"))
        [_0x2a40("0xd")](_0x2a40("0xb"), _0x2a40("0x3"))
        [_0x2a40("0xc")](""),
      $(_0x2a40("0x11"))["remove"](),
      $(_0x2a40("0x0"))[_0x2a40("0xf")]();
  }),
  $(_0x2a40("0x5"))["remove"](),
  $(_0x2a40("0x9"))[_0x2a40("0xf")](),
  $(_0x2a40("0x10"))[_0x2a40("0xf")](),
  $(_0x2a40("0x6"))
    [_0x2a40("0xd")](_0x2a40("0xb"), _0x2a40("0x3"))
    [_0x2a40("0xc")](""),
  $(_0x2a40("0x7"))[_0x2a40("0xf")](),
  $(_0x2a40("0x2"))[_0x2a40("0xf")](),
  $(_0x2a40("0x8"))[_0x2a40("0xf")]();
