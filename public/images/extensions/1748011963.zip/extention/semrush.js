$(".srf-navbar__right").remove();

